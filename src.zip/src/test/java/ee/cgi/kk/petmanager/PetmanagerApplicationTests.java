package ee.cgi.kk.petmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetmanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
