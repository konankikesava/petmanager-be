package ee.cgi.kk.petmanager.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "PET")
public class Pet {


	@Id
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_Sequence")
//	@SequenceGenerator(name = "id_Sequence", sequenceName = "PET_SEQ")
	@GenericGenerator(name = "id_Sequence", strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator", parameters = {
			@Parameter(name = "PET_SEQ", value = "SEQUENCE") })
	@Column(name = "ID")
	private Long id;

	@Column(name = "V_NAME")
	private String cpetname;

	@Column(name = "V_BREED")
	private String cpetbreed;

	@Column(name = "C_GENDER")
	private String cpetgender;

	@Column(name = "N_BIRTH_DATE")
	private String startdate;

	@Column(name = "N_DEATH_DATE")
	private String enddate;

	public Pet() {
	}

	/**
	 * For unit testing
	 */
	public Pet(String petname, String cpetbreed, String cpetgender, 
			String startdate, String enddate) {

		this.cpetname = petname;
		this.cpetbreed = cpetbreed;
		this.cpetgender = cpetgender;
		this.startdate = startdate;
		this.enddate = enddate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}



	public String getStartdate() {
		return startdate;
	}

	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}

	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	public String getCpetname() {
		return cpetname;
	}

	public void setCpetname(String cpetname) {
		this.cpetname = cpetname;
	}

	public String getCpetBreed() {
		return cpetbreed;
	}

	public void setCpetBreed(String cpetbreed) {
		this.cpetbreed = cpetbreed;
	}

	public String getCpetgender() {
		return cpetgender;
	}

	public void setCpetgender(String cpetgender) {
		this.cpetgender = cpetgender;
	}

}
